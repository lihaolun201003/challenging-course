/*!
 * @file Adafruit_ILI9341.cpp
 *
 * @mainpage Adafruit ILI9341 TFT Displays
 *
 * @section intro_sec Introduction
 *
 * This is the documentation for Adafruit's ILI9341 driver for the
 * Arduino platform.
 *
 * This library works with the Adafruit 2.8" Touch Shield V2 (SPI)
 *    http://www.adafruit.com/products/1651
 *
 * Adafruit 2.4" TFT LCD with Touchscreen Breakout w/MicroSD Socket - ILI9341
 *    https://www.adafruit.com/product/2478
 *
 * 2.8" TFT LCD with Touchscreen Breakout Board w/MicroSD Socket - ILI9341
 *    https://www.adafruit.com/product/1770
 *
 * 2.2" 18-bit color TFT LCD display with microSD card breakout - ILI9340
 *    https://www.adafruit.com/product/1770
 *
 * TFT FeatherWing - 2.4" 320x240 Touchscreen For All Feathers
 *    https://www.adafruit.com/product/3315
 *
 * These displays use SPI to communicate, 4 or 5 pins are required
 * to interface (RST is optional).
 *
 * Adafruit invests time and resources providing this open source code,
 * please support Adafruit and open-source hardware by purchasing
 * products from Adafruit!
 *
 * @section dependencies Dependencies
 *
 * This library depends on <a href="https://github.com/adafruit/Adafruit_GFX">
 * Adafruit_GFX</a> being present on your system. Please make sure you have
 * installed the latest version before using this library.
 *
 * @section author Author
 *
 * Written by Limor "ladyada" Fried for Adafruit Industries.
 *
 * @section license License
 *
 * BSD license, all text here must be included in any redistribution.
 *
 */

// Initialization values adapted from Adafruit_ILI9341 1.6.4 (BSD).
// Keep DISPON separate so the first complete image is in GRAM before it appears.
#include "boot_display.h"
#include "air_config.h"
#include <Arduino.h>

namespace {
const uint8_t config[] = {
  0xEF, 3, 0x03, 0x80, 0x02,
  0xCF, 3, 0x00, 0xC1, 0x30,
  0xED, 4, 0x64, 0x03, 0x12, 0x81,
  0xE8, 3, 0x85, 0x00, 0x78,
  0xCB, 5, 0x39, 0x2C, 0x00, 0x34, 0x02,
  0xF7, 1, 0x20,
  0xEA, 2, 0x00, 0x00,
  ILI9341_PWCTR1, 1, 0x23,
  ILI9341_PWCTR2, 1, 0x10,
  ILI9341_VMCTR1, 2, 0x3E, 0x28,
  ILI9341_VMCTR2, 1, 0x86,
  ILI9341_MADCTL, 1, 0x48,
  ILI9341_VSCRSADD, 2, 0x00, 0x00,
  ILI9341_PIXFMT, 1, 0x55,
  ILI9341_FRMCTR1, 2, 0x00, 0x18,
  ILI9341_DFUNCTR, 3, 0x08, 0x82, 0x27,
  0xF2, 1, 0x00,
  ILI9341_GAMMASET, 1, 0x01,
  ILI9341_GMCTRP1, 15, 0x0F, 0x31, 0x2B, 0x0C, 0x0E, 0x08,
    0x4E, 0xF1, 0x37, 0x07, 0x10, 0x03, 0x0E, 0x09, 0x00,
  ILI9341_GMCTRN1, 15, 0x00, 0x0E, 0x14, 0x03, 0x11, 0x07,
    0x31, 0xC1, 0x48, 0x08, 0x0F, 0x0C, 0x31, 0x36, 0x0F,
  0
};
}

void BootDisplay::begin(uint32_t frequency) {
  // Base class has _rst=-1: use our explicit, datasheet-compliant reset.
  // Avoid the stock 100 ms HIGH + 100 ms LOW + 200 ms HIGH sequence.
  initSPI(frequency);
  pinMode(resetPin_, OUTPUT);
  digitalWrite(resetPin_, LOW);
  delay(10);
  digitalWrite(resetPin_, HIGH);
  delay(120);  // Valid even when resetting a display that was already awake.

  sendCommand(ILI9341_DISPOFF);
  const uint8_t *cursor = config;
  while (*cursor) {
    const uint8_t command = *cursor++;
    const uint8_t length = *cursor++;
    sendCommand(command, cursor, length);
    cursor += length;
  }
  sendCommand(ILI9341_SLPOUT);
  delay(120);  // Preserve the required wake-up delay.
#if !AIR_ENABLE_BLUETOOTH
  Serial.println(F("LCD initialized: display OFF until first frame is ready"));
#endif
}
